content.js    --储存的index.html的网址相关信息
index.html 为灰色简约主题站点
